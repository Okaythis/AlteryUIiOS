// Copyright © Protectoria. All rights reserved.

#import <UIKit/UIKit.h>

@interface PSAAuthTimerProgressView : UIView

- (instancetype)initWithCoder:(NSCoder *)aDecoder;
- (void)setProgress:(float)progress;
- (float)getProgress;

@end
